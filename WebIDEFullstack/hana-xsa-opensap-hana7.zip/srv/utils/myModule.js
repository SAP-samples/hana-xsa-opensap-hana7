"use strict";

module.exports = {
   helloModule: function(){
   	return "Hello World from My First Module";
   }
};